
import React from 'react';
import ReactDOM from 'react-dom/client';

const ManualApp: React.FC = () => {
    return (
        <div className="min-h-screen font-sans scroll-smooth">
            {/* HERO SECTION */}
            <section className="relative h-screen flex items-center justify-center overflow-hidden bg-indigo-950">
                <div className="absolute inset-0 opacity-20 bg-[url('https://images.unsplash.com/photo-1574629810360-7efbbe195018?q=80&w=2093&auto=format&fit=crop')] bg-cover bg-center"></div>
                <div className="absolute inset-0 bg-gradient-to-b from-transparent via-gray-900/50 to-gray-900"></div>
                
                <div className="relative z-10 text-center px-4 max-w-4xl animate-fadeIn">
                    <div className="inline-block px-4 py-1 rounded-full bg-indigo-500/20 border border-indigo-500/30 text-indigo-400 font-black text-[10px] uppercase tracking-widest mb-6">
                        Guía Maestra de Usuario
                    </div>
                    <h1 className="text-6xl md:text-8xl font-black italic uppercase tracking-tighter mb-4 drop-shadow-2xl">
                        PLAYERS <span className="text-indigo-500">LD</span>
                    </h1>
                    <p className="text-xl md:text-2xl text-gray-300 font-medium max-w-2xl mx-auto mb-10 leading-tight">
                        Transforma la gestión de tu equipo amateur en una experiencia de <span className="text-white font-bold italic">Primera División</span>.
                    </p>
                    <div className="flex flex-col sm:flex-row justify-center gap-4">
                        <a href="#instalacion" className="px-10 py-5 bg-indigo-600 hover:bg-indigo-700 text-white font-black rounded-2xl shadow-xl transition-all hover:scale-105 active:scale-95 uppercase tracking-tighter">
                            Empezar Instalación
                        </a>
                        <a href="#jugador" className="px-10 py-5 bg-white/10 hover:bg-white/20 text-white font-black rounded-2xl border border-white/10 transition-all uppercase tracking-tighter">
                            Guía del Jugador
                        </a>
                    </div>
                </div>

                <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce">
                    <svg className="w-8 h-8 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 14l-7 7-7-7m14-8l-7 7-7-7"></path></svg>
                </div>
            </section>

            {/* INSTALACIÓN: PANEL MAESTRO */}
            <section id="instalacion" className="py-24 px-4 bg-gray-900">
                <div className="max-w-6xl mx-auto">
                    <div className="flex flex-col md:flex-row items-center gap-16">
                        <div className="flex-1">
                            <h2 className="text-4xl md:text-5xl font-black uppercase italic tracking-tighter mb-6">
                                <span className="text-indigo-500">01.</span> Encendido de la Máquina
                            </h2>
                            <div className="space-y-8">
                                <div className="flex gap-4">
                                    <div className="flex-shrink-0 w-10 h-10 rounded-full bg-indigo-600 flex items-center justify-center font-black">1</div>
                                    <div>
                                        <h3 className="text-xl font-bold mb-2">Acceso al Panel Maestro</h3>
                                        <p className="text-gray-400">En la pantalla de inicio, escribe el código maestro <span className="bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded font-mono">PLAYERLD</span> para desbloquear la creación de licencias.</p>
                                    </div>
                                </div>
                                <div className="flex gap-4">
                                    <div className="flex-shrink-0 w-10 h-10 rounded-full bg-indigo-600 flex items-center justify-center font-black">2</div>
                                    <div>
                                        <h3 className="text-xl font-bold mb-2">Crear el Equipo (Licencia)</h3>
                                        <p className="text-gray-400">Define el nombre de tu equipo (Ej: "Los Galácticos"). El sistema generará una base de datos exclusiva para ustedes.</p>
                                    </div>
                                </div>
                                <div className="flex gap-4">
                                    <div className="flex-shrink-0 w-10 h-10 rounded-full bg-indigo-600 flex items-center justify-center font-black">3</div>
                                    <div>
                                        <h3 className="text-xl font-bold mb-2">Login Corporativo</h3>
                                        <p className="text-gray-400">Sal del Panel Maestro y ahora escribe el nombre de tu equipo para entrar a su terreno privado.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="flex-1 w-full max-w-sm">
                            <div className="aspect-[9/16] bg-black rounded-[3rem] border-[8px] border-gray-800 shadow-2xl overflow-hidden relative p-4 flex flex-col justify-center items-center text-center">
                                <div className="text-6xl mb-4">🔓</div>
                                <div className="w-full h-12 bg-gray-900 border-2 border-indigo-500 rounded-xl mb-4 flex items-center justify-center font-black text-indigo-500">PLAYERLD</div>
                                <div className="w-full py-3 bg-indigo-600 rounded-xl font-black text-xs uppercase">Simulador Activo</div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* ROLES: ADMIN VS JUGADOR */}
            <section className="py-24 px-4 bg-black/40">
                <div className="max-w-6xl mx-auto text-center mb-16">
                    <h2 className="text-4xl md:text-6xl font-black italic uppercase tracking-tighter mb-4">Múltiples Mandos</h2>
                    <p className="text-gray-500 uppercase font-black text-xs tracking-[0.3em]">Una app, diferentes poderes</p>
                </div>

                <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-8">
                    {/* Tarjeta Admin */}
                    <div className="bg-gradient-to-br from-indigo-900/40 to-gray-800/40 p-10 rounded-[3rem] border border-white/5 group hover:border-indigo-500/50 transition-all">
                        <div className="text-5xl mb-6">🛡️</div>
                        <h3 className="text-3xl font-black italic uppercase mb-4 tracking-tight">Administrador / DT</h3>
                        <ul className="space-y-4 text-gray-400 font-medium">
                            <li className="flex items-center gap-2"><span className="text-indigo-500">✔</span> Carga de jugadores y PINs.</li>
                            <li className="flex items-center gap-2"><span className="text-indigo-500">✔</span> Creación de Torneos y Fechas.</li>
                            <li className="flex items-center gap-2"><span className="text-indigo-500">✔</span> Carga de Goles y Estadísticas.</li>
                            <li className="flex items-center gap-2"><span className="text-indigo-500">✔</span> Gestión de Votaciones y Deudores.</li>
                        </ul>
                    </div>

                    {/* Tarjeta Jugador */}
                    <div id="jugador" className="bg-gradient-to-br from-gray-800/40 to-gray-800/20 p-10 rounded-[3rem] border border-white/5 group hover:border-green-500/50 transition-all">
                        <div className="text-5xl mb-6">⚽</div>
                        <h3 className="text-3xl font-black italic uppercase mb-4 tracking-tight">Jugador de Campo</h3>
                        <ul className="space-y-4 text-gray-400 font-medium">
                            <li className="flex items-center gap-2"><span className="text-green-500">✔</span> Confirmación de asistencia (Semáforo).</li>
                            <li className="flex items-center gap-2"><span className="text-green-500">✔</span> Votación de compañeros (Cuarto Oscuro).</li>
                            <li className="flex items-center gap-2"><span className="text-green-500">✔</span> Acceso a Chat y Arcade.</li>
                            <li className="flex items-center gap-2"><span className="text-green-500">✔</span> Seguimiento de ranking personal.</li>
                        </ul>
                    </div>
                </div>
            </section>

            {/* PASO A PASO: DÍA DEL PARTIDO */}
            <section className="py-24 px-4 bg-gray-900">
                <div className="max-w-4xl mx-auto">
                    <h2 className="text-4xl font-black uppercase italic tracking-tighter mb-16 text-center">El Ciclo de Juego</h2>
                    <div className="relative border-l-4 border-indigo-600/30 pl-8 space-y-16">
                        <div className="relative">
                            <div className="absolute -left-[44px] top-0 w-8 h-8 rounded-full bg-indigo-600 border-4 border-gray-900"></div>
                            <h4 className="text-xl font-black uppercase text-indigo-400 mb-2">1. La Convocatoria</h4>
                            <p className="text-gray-400">El DT publica la fecha. Los jugadores tienen 48hs para marcar su tarjeta verde (✅) o roja (❌).</p>
                        </div>
                        <div className="relative">
                            <div className="absolute -left-[44px] top-0 w-8 h-8 rounded-full bg-indigo-600 border-4 border-gray-900"></div>
                            <h4 className="text-xl font-black uppercase text-indigo-400 mb-2">2. El Estadio</h4>
                            <p className="text-gray-400">Usa el botón de mapa en la tarjeta para abrir la ubicación exacta en Google Maps.</p>
                        </div>
                        <div className="relative">
                            <div className="absolute -left-[44px] top-0 w-8 h-8 rounded-full bg-indigo-600 border-4 border-gray-900"></div>
                            <h4 className="text-xl font-black uppercase text-indigo-400 mb-2">3. Post-Partido (Carga)</h4>
                            <p className="text-gray-400">El Admin toca "🛠️ Cargar Datos" y anota quién metió gol, quién trajo las pelotas y quién ya pagó.</p>
                        </div>
                        <div className="relative">
                            <div className="absolute -left-[44px] top-0 w-8 h-8 rounded-full bg-indigo-600 border-4 border-gray-900"></div>
                            <h4 className="text-xl font-black uppercase text-indigo-400 mb-2">4. La Urna</h4>
                            <p className="text-gray-400">Se habilita el "Cuarto Oscuro". Es obligatorio votar a tus compañeros para ver los resultados.</p>
                        </div>
                    </div>
                </div>
            </section>

            {/* 3er TIEMPO */}
            <section className="py-24 px-4 bg-yellow-500 text-black">
                <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center gap-10">
                    <div className="text-8xl">🍻</div>
                    <div className="flex-1">
                        <h2 className="text-5xl font-black uppercase italic tracking-tighter mb-4 leading-none">Cervezocracia Garantizada</h2>
                        <p className="text-xl font-bold opacity-80 mb-6">Nunca más discutas por el costo de la birra. La app divide los gastos del 3er Tiempo por los presentes y marca a los deudores en tiempo real.</p>
                        <div className="inline-block px-4 py-2 bg-black text-white font-black rounded-lg text-sm uppercase">Módulo de Tesorería Integrado</div>
                    </div>
                </div>
            </section>

            {/* FOOTER */}
            <footer className="py-12 bg-black text-center border-t border-white/5">
                <p className="text-gray-500 font-bold uppercase text-[10px] tracking-widest">© 2025 PLAYERS LD • Digital Sport Management</p>
                <div className="mt-4 flex justify-center gap-4">
                    <a href="/index.html" className="text-indigo-400 font-black hover:underline uppercase text-xs italic">Ir a la Aplicación →</a>
                </div>
            </footer>

            <style dangerouslySetInnerHTML={{ __html: `
                @keyframes fadeIn {
                    from { opacity: 0; transform: translateY(20px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                .animate-fadeIn {
                    animation: fadeIn 1s ease-out forwards;
                }
                html {
                    scroll-behavior: smooth;
                }
            `}} />
        </div>
    );
};

ReactDOM.createRoot(document.getElementById('manual-root')!).render(
    <React.StrictMode>
        <ManualApp />
    </React.StrictMode>
);
