
import React, { useState } from 'react';
import type { Player } from '../types.ts';

export const UserSelectionModal: React.FC<{
    players: Player[];
    onSelectUser: (player: Player) => void;
    isPinAuthEnabled: boolean;
    onTogglePinAuth: () => void;
}> = ({ players, onSelectUser, isPinAuthEnabled, onTogglePinAuth }) => {
    const [selectedPlayer, setSelectedPlayer] = useState<Player | null>(null);
    const [pin, setPin] = useState('');
    const [error, setError] = useState('');

    const handlePinSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (selectedPlayer && pin === selectedPlayer.pin) {
            onSelectUser(selectedPlayer);
        } else {
            setError('PIN incorrecto. Intenta de nuevo.');
            setPin('');
        }
    };

    const handleSelectPlayer = (player: Player) => {
        if (!isPinAuthEnabled) {
            onSelectUser(player);
        } else {
            setSelectedPlayer(player);
            setError('');
            setPin('');
        }
    };

    const handleGoBack = () => {
        setSelectedPlayer(null);
        setError('');
        setPin('');
    };

    const sortedPlayers = [...players].sort((a, b) => a.nickname.localeCompare(b.nickname));

    return (
        <div className="fixed inset-0 bg-indigo-950 bg-opacity-95 flex justify-center items-center z-50 p-4 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]">
            <div className="bg-white dark:bg-gray-800 rounded-3xl shadow-2xl w-full max-w-md overflow-hidden" onClick={e => e.stopPropagation()}>
                <header className="p-6 bg-gray-50 dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700 text-center">
                    <h2 className="text-2xl font-black text-gray-800 dark:text-gray-100 uppercase tracking-tighter">¿Quién está jugando?</h2>
                    <p className="text-[10px] font-black text-indigo-500 uppercase tracking-widest mt-1">Selecciona tu perfil para entrar</p>
                </header>
                
                <main className="p-6">
                    {!selectedPlayer ? (
                        <>
                            {players.length === 0 ? (
                                <div className="text-center py-10 animate-pulse">
                                    <div className="text-4xl mb-2">📡</div>
                                    <p className="text-sm font-bold text-gray-400 uppercase">Buscando jugadores en la nube...</p>
                                    <p className="text-[10px] text-gray-400 mt-2 px-10 leading-tight">Si esta pantalla no cambia, revisa que tus reglas de Firebase permitan leer datos.</p>
                                </div>
                            ) : (
                                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 max-h-96 overflow-y-auto pr-2 custom-scrollbar">
                                    {sortedPlayers.map(player => (
                                        <button
                                            key={player.id}
                                            onClick={() => handleSelectPlayer(player)}
                                            className="flex flex-col items-center p-3 rounded-2xl hover:bg-indigo-50 dark:hover:bg-indigo-900/30 transition-all border-2 border-transparent hover:border-indigo-200 group"
                                        >
                                            <div className="relative mb-2">
                                                {player.photoUrl ? (
                                                    <img src={player.photoUrl} alt={player.nickname} className="w-16 h-16 rounded-full object-cover border-2 border-white dark:border-gray-700 shadow-md group-hover:scale-110 transition-transform" />
                                                ) : (
                                                    <div className="w-16 h-16 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center text-gray-400 shadow-inner">
                                                        <span className="text-2xl">👤</span>
                                                    </div>
                                                )}
                                                {player.isSuperAdmin && <span className="absolute -top-1 -right-1 text-xs" title="Administrador">👑</span>}
                                            </div>
                                            <p className="text-xs font-black text-gray-700 dark:text-gray-200 text-center uppercase tracking-tighter leading-none">{player.nickname}</p>
                                        </button>
                                    ))}
                                </div>
                            )}
                            <div className="mt-6 text-center text-[9px] text-gray-400 font-bold uppercase tracking-widest leading-tight">
                                <p>Seguridad activa. Usa el PIN 0000 para entrar por primera vez.</p>
                            </div>
                        </>
                    ) : (
                        <form onSubmit={handlePinSubmit} className="space-y-6 animate-zoomIn">
                            <div className="flex flex-col items-center">
                                <div className="relative mb-4">
                                    {selectedPlayer.photoUrl ? (
                                        <img src={selectedPlayer.photoUrl} alt={selectedPlayer.nickname} className="w-24 h-24 rounded-full object-cover border-4 border-indigo-500 shadow-xl" />
                                    ) : (
                                        <div className="w-24 h-24 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center text-4xl shadow-inner">👤</div>
                                    )}
                                </div>
                                <h3 className="text-2xl font-black text-gray-800 dark:text-gray-100 uppercase tracking-tighter italic">{selectedPlayer.nickname}</h3>
                                <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mt-1">Ingresa tu código de 4 dígitos</p>
                            </div>
                            
                            <div>
                                <input
                                    type="password"
                                    maxLength={4}
                                    inputMode="numeric"
                                    pattern="\d{4}"
                                    value={pin}
                                    onChange={(e) => {
                                        setPin(e.target.value.replace(/\D/g, ''));
                                        setError('');
                                    }}
                                    className="block w-full rounded-2xl border-4 border-gray-100 dark:bg-gray-900 dark:border-gray-700 dark:text-white text-center text-4xl font-black p-4 tracking-[0.5em] focus:border-indigo-500 outline-none transition-all shadow-inner"
                                    autoFocus
                                    placeholder="••••"
                                />
                                {error && <p className="mt-3 text-red-500 text-[10px] font-black text-center uppercase bg-red-50 dark:bg-red-900/30 p-2 rounded-lg">{error}</p>}
                            </div>

                            <div className="flex gap-3">
                                <button type="button" onClick={handleGoBack} className="flex-1 py-4 text-xs font-black uppercase text-gray-500 bg-gray-100 dark:bg-gray-700 rounded-2xl hover:bg-gray-200 transition-colors">
                                    Cancelar
                                </button>
                                <button type="submit" className="flex-2 px-8 py-4 text-xs font-black uppercase text-white bg-indigo-600 rounded-2xl hover:bg-indigo-700 shadow-lg shadow-indigo-500/30 transition-all active:scale-95">
                                    ENTRAR AHORA
                                </button>
                            </div>
                        </form>
                    )}
                </main>
            </div>
        </div>
    );
};
