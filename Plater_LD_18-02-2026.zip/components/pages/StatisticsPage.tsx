import React, { useMemo, useState } from 'react';
import type { PlayerStats, Player, Match, Opponent, ThirdHalfItem } from '../../types.ts';
import { AttendanceStatus, PlayerRole } from '../../types.ts';
import { useToast } from '../../hooks/useToast.ts';

interface StatisticsPageProps {
    stats: PlayerStats[];
    canViewRatings: boolean;
    onViewProfile: (player: Player) => void;
    teamPenaltiesAgainst: number;
    matches?: Match[];
    currentUser: Player;
    opponents: Opponent[];
    isSuperAdmin?: boolean;
    isAdmin?: boolean;
    onPardonPlayer?: (matchId: number, playerId: number) => void;
}

const StatCard: React.FC<{ title: string; children: React.ReactNode, icon?: string, className?: string }> = ({ title, children, icon, className }) => (
    <div className={`bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 ${className}`}>
        <h3 className="text-xl font-bold text-gray-800 dark:text-gray-100 mb-4 flex items-center gap-2">
            {icon && <span className="text-2xl">{icon}</span>}
            {title}
        </h3>
        {children}
    </div>
);

const EmptyState: React.FC<{ message: string }> = ({ message }) => (
    <p className="text-center py-4 text-gray-500 dark:text-gray-400">{message}</p>
);

const TableHeader: React.FC<{ columns: string[] }> = ({ columns }) => (
    <thead className="bg-gray-100 dark:bg-gray-700">
        <tr>
            {columns.map((col, i) => (
                <th key={i} className={`p-3 text-sm font-semibold tracking-wide ${i === 0 ? 'text-left' : 'text-center'}`}>{col}</th>
            ))}
        </tr>
    </thead>
);

const Podium: React.FC<{ top3: PlayerStats[] }> = ({ top3 }) => {
    if (top3.length === 0) return <EmptyState message="Votaciones pendientes." />;
    const [first, second, third] = top3;
    const PodiumItem = ({ stat, position, color, height }: { stat: PlayerStats | undefined, position: number, color: string, height: string }) => {
        if (!stat) return <div className="flex-1"></div>;
        return (
            <div className="flex flex-col items-center justify-end flex-1">
                 <div className="relative mb-2">
                    <img src={stat.player.photoUrl} alt={stat.player.nickname} className={`w-14 h-14 rounded-full border-4 ${color} object-cover`} />
                    <div className={`absolute -top-3 -right-3 w-7 h-7 rounded-full ${color} flex items-center justify-center text-white font-bold text-sm shadow-md`}>
                        {position}
                    </div>
                </div>
                <p className="font-bold text-sm text-center truncate w-full">{stat.player.nickname}</p>
                <p className="text-xs font-bold text-yellow-600 mb-1">{stat.avgRating.toFixed(2)} ★</p>
                <div className={`w-full ${color} rounded-t-lg opacity-80`} style={{ height }}></div>
            </div>
        );
    }
    return (
        <div className="flex items-end justify-center h-48 gap-2 mb-6 px-4">
            <PodiumItem stat={second} position={2} color="bg-gray-400 border-gray-400" height="40%" />
            <PodiumItem stat={first} position={1} color="bg-yellow-400 border-yellow-400" height="60%" />
            <PodiumItem stat={third} position={3} color="bg-orange-400 border-orange-400" height="30%" />
        </div>
    );
};

const PRESET_ITEM_EMOJIS: {[key: string]: string} = { beer: '🍺', fernet: '🍷', pizza: '🍕', asado: '🥩', ice: '🧊', soda: '🥤', chips: '🍟', other: '🛒' };

export const StatisticsPage: React.FC<StatisticsPageProps> = ({ stats, canViewRatings, onViewProfile, teamPenaltiesAgainst, matches = [], currentUser, opponents, isAdmin, onPardonPlayer }) => {
    const toast = useToast();
    const [view, setView] = useState<'total' | 'match' | 'credits'>('total');
    const [timeRange, setTimeRange] = useState<'WEEK' | 'MONTH' | 'ALL'>('ALL');
    const [selectedMatchId, setSelectedMatchId] = useState<number | null>(null);

    const filteredMatches = useMemo(() => {
        let base = matches.filter(m => m.status === 'FINALIZADO');
        const now = new Date();
        if (timeRange === 'WEEK') {
            const lastWeek = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
            base = base.filter(m => new Date(m.date).getTime() >= lastWeek.getTime());
        } else if (timeRange === 'MONTH') {
            const lastMonth = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
            base = base.filter(m => new Date(m.date).getTime() >= lastMonth.getTime());
        }
        return base.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    }, [matches, timeRange]);

    const finishedMatches = useMemo(() => matches.filter(m => m.status === 'FINALIZADO').sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()), [matches]);
    const selectedMatch = useMemo(() => selectedMatchId ? finishedMatches.find(m => m.id === selectedMatchId) : null, [selectedMatchId, finishedMatches]);

    const perMatchStats = useMemo(() => {
        if (!selectedMatch) return null;
        const confirmedPlayers = selectedMatch.playerStatuses
            .filter(ps => ps.attendanceStatus === 'CONFIRMED')
            .map(ps => {
                const player = stats.find(s => s.player.id === ps.playerId)?.player;
                if (!player) return null;
                const totalGoals = (ps.goalsPlay || 0) + (ps.goalsPenalty || 0) + (ps.goalsHeader || 0) + (ps.goalsSetPiece || 0);
                return { player, ...ps, totalGoals };
            })
            .filter((p): p is NonNullable<typeof p> => p !== null);
        const goalScorers = confirmedPlayers.filter(p => p.totalGoals > 0).sort((a, b) => b.totalGoals - a.totalGoals);
        const discipline = confirmedPlayers.filter(p => (p.yellowCards || 0) > 0 || p.redCard).sort((a, b) => ((b.redCard ? 2 : 0) + (b.yellowCards || 0)) - ((a.redCard ? 2 : 0) + (a.yellowCards || 0)));
        return { goalScorers, discipline };
    }, [selectedMatch, stats]);

    // Fantasy Credits Calculation based on Filtered Matches
    const fantasyRanking = useMemo(() => {
        return stats.map(stat => {
            let credits = 0;
            const myMatches = filteredMatches.filter(m => m.playerStatuses.some(ps => ps.playerId === stat.player.id && ps.attendanceStatus === AttendanceStatus.CONFIRMED));
            
            credits += (myMatches.length * 2);
            myMatches.forEach(m => {
                const ps = m.playerStatuses.find(p => p.playerId === stat.player.id)!;
                credits += (ps.goalsPlay || 0) * 3;
                credits += (ps.goalsHeader || 0) * 5;
                credits += (ps.goalsPenalty || 0) * 3;
                credits += (ps.goalsSetPiece || 0) * 4;
                credits += (ps.assists || 0) * 2;
                credits -= (ps.yellowCards || 0) * 2;
                if (ps.redCard) credits -= 5;
                credits -= (ps.ownGoals || 0) * 5;
                credits -= (ps.penaltiesMissed || 0) * 3;
                credits -= (ps.badThrowIns || 0) * 1;
                credits -= (ps.badFreeKicks || 0) * 1;
                credits -= (ps.majorErrors || 0) * 2;

                if (m.opponentScore === 0 && (stat.player.role === PlayerRole.ARQUERO || stat.player.role.includes('Defensa') || stat.player.role.includes('Lateral'))) {
                    credits += 5;
                }
            });

            if (stat.player.gamePoints) credits += Math.round(stat.player.gamePoints / 10);
            return { ...stat, credits, filteredPJ: myMatches.length };
        }).filter(s => s.filteredPJ > 0 || s.credits > 0).sort((a, b) => b.credits - a.credits);
    }, [stats, filteredMatches]);

    const goalScorers = [...stats].filter(s => s.totalGoals > 0).sort((a, b) => b.totalGoals - a.totalGoals);
    const ratingRanking = canViewRatings ? [...stats].filter(s => s.avgRating > 0).sort((a, b) => b.avgRating - a.avgRating) : [];
    
    const thirdHalfStats = useMemo(() => {
        let totalBeerLitros = 0, totalSpentThirdHalf = 0, totalSpentCourt = 0;
        const itemsMap = new Map<string, {name: string, qty: number, emoji: string}>();
        filteredMatches.forEach(m => {
            totalSpentCourt += m.courtFee;
            if (m.thirdHalf) {
                totalSpentThirdHalf += m.thirdHalf.totalSpent;
                m.thirdHalf.items.forEach((item: ThirdHalfItem) => {
                    if (item.id === 'beer') totalBeerLitros += item.quantity;
                    let emoji = PRESET_ITEM_EMOJIS[item.id] || '🛒';
                    const current = itemsMap.get(item.id) || { name: item.name, qty: 0, emoji };
                    itemsMap.set(item.id, { name: item.name, qty: current.qty + item.quantity, emoji: current.emoji });
                });
            }
        });
        const grandTotal = totalSpentCourt + totalSpentThirdHalf;
        return { totalBeerLitros, totalSpentThirdHalf, totalSpentCourt, courtPerc: grandTotal > 0 ? (totalSpentCourt / grandTotal) * 100 : 50, thirdHalfPerc: grandTotal > 0 ? (totalSpentThirdHalf / grandTotal) * 100 : 50 };
    }, [filteredMatches]);

    const formatter = new Intl.NumberFormat('es-AR', { style: 'currency', currency: 'ARS', maximumFractionDigits: 0 });

    return (
        <div className="space-y-8 pb-12">
            <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
                <h2 className="text-3xl font-bold text-center text-gray-800 dark:text-gray-100">Estadísticas</h2>
                <div className="flex bg-gray-200 dark:bg-gray-700 p-1 rounded-xl text-xs font-black uppercase">
                    <button onClick={() => setTimeRange('WEEK')} className={`px-3 py-1.5 rounded-lg transition-all ${timeRange === 'WEEK' ? 'bg-indigo-600 text-white shadow-lg' : 'text-gray-500'}`}>Semana</button>
                    <button onClick={() => setTimeRange('MONTH')} className={`px-3 py-1.5 rounded-lg transition-all ${timeRange === 'MONTH' ? 'bg-indigo-600 text-white shadow-lg' : 'text-gray-500'}`}>Mes</button>
                    <button onClick={() => setTimeRange('ALL')} className={`px-3 py-1.5 rounded-lg transition-all ${timeRange === 'ALL' ? 'bg-indigo-600 text-white shadow-lg' : 'text-gray-500'}`}>Todo</button>
                </div>
            </div>
            
            <div className="flex justify-center bg-gray-200 dark:bg-gray-700 p-1 rounded-lg gap-1">
                <button onClick={() => setView('total')} className={`px-4 py-2 text-xs md:text-sm font-bold rounded-md flex-1 transition-all ${view === 'total' ? 'bg-white dark:bg-gray-800 shadow text-indigo-600' : 'text-gray-600 dark:text-gray-300'}`}>Ranking General</button>
                <button onClick={() => setView('credits')} className={`px-4 py-2 text-xs md:text-sm font-bold rounded-md flex-1 transition-all ${view === 'credits' ? 'bg-white dark:bg-gray-800 shadow text-green-600' : 'text-gray-600 dark:text-gray-300'}`}>💳 Créditos Fantasy</button>
                <button onClick={() => { setView('match'); setSelectedMatchId(null); }} className={`px-4 py-2 text-xs md:text-sm font-bold rounded-md flex-1 transition-all ${view === 'match' ? 'bg-white dark:bg-gray-800 shadow text-indigo-600' : 'text-gray-600 dark:text-gray-300'}`}>Por Partido</button>
            </div>

            {view === 'credits' && (
                <div className="animate-fadeIn">
                    <StatCard title={`Ranking Créditos - ${timeRange === 'WEEK' ? 'Esta Semana' : timeRange === 'MONTH' ? 'Este Mes' : 'Histórico'}`} icon="💳" className="border-2 border-green-500 bg-green-50 dark:bg-green-900/10">
                        <div className="overflow-x-auto rounded-xl shadow-inner bg-white dark:bg-gray-900">
                            <table className="w-full text-left">
                                <TableHeader columns={['#', 'Jugador', 'PJ', 'Suman', 'Restan', 'Arcade', 'TOTAL']} />
                                <tbody>
                                    {fantasyRanking.length > 0 ? fantasyRanking.map((stat, idx) => (
                                        <tr key={stat.player.id} className="border-b dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800/50">
                                            <td className="p-3 font-bold text-gray-400">{idx + 1}</td>
                                            <td className="p-3 font-bold flex items-center gap-2">
                                                <img src={stat.player.photoUrl} className="w-8 h-8 rounded-full" />
                                                {stat.player.nickname}
                                            </td>
                                            <td className="p-3 text-center">{stat.filteredPJ}</td>
                                            <td className="p-3 text-center text-green-600">+{(stat.credits > 0 ? stat.credits : 0)}</td>
                                            <td className="p-3 text-center text-red-500">...</td>
                                            <td className="p-3 text-center text-blue-500">{stat.player.gamePoints ? Math.round(stat.player.gamePoints / 10) : 0}</td>
                                            <td className="p-3 text-center font-black text-xl text-indigo-600">{stat.credits}</td>
                                        </tr>
                                    )) : <tr><td colSpan={7} className="p-10 text-center italic text-gray-400">No hay datos para este período.</td></tr>}
                                </tbody>
                            </table>
                        </div>
                    </StatCard>
                </div>
            )}

            {view === 'total' && (
                <div className="space-y-8 animate-fadeIn">
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                        <div className="bg-gray-800 text-white p-6 rounded-3xl shadow-xl flex flex-col justify-center items-center">
                            <p className="text-xs uppercase font-black text-gray-400 tracking-widest mb-2">Penales en Contra</p>
                            <p className="text-7xl font-black text-red-500 drop-shadow-lg">{teamPenaltiesAgainst}</p>
                        </div>
                        <StatCard title="🏆 Podio de Votación" icon="⭐" className="lg:col-span-2">
                            {canViewRatings ? <Podium top3={ratingRanking.slice(0, 3)} /> : <EmptyState message="Completa tus votos para ver el podio." />}
                        </StatCard>
                    </div>
                    
                    <StatCard title={`Economía & Birras (${timeRange})`} icon="🍻" className="bg-gradient-to-br from-white to-yellow-50 dark:from-gray-800 dark:to-yellow-950/10">
                        <div className="mb-6">
                            <h4 className="text-xs font-black text-gray-400 uppercase mb-2">Inversión: Cancha vs Joda</h4>
                            <div className="h-10 bg-gray-200 dark:bg-gray-700 rounded-2xl overflow-hidden flex shadow-inner">
                                <div className="bg-blue-500 flex items-center justify-center text-[10px] font-black text-white" style={{ width: `${thirdHalfStats.courtPerc}%` }}>CANCHA {Math.round(thirdHalfStats.courtPerc)}%</div>
                                <div className="bg-yellow-500 flex items-center justify-center text-[10px] font-black text-white" style={{ width: `${thirdHalfStats.thirdHalfPerc}%` }}>BIRRA {Math.round(thirdHalfStats.thirdHalfPerc)}%</div>
                            </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div className="bg-white dark:bg-gray-900 p-4 rounded-2xl text-center shadow-sm">
                                <p className="text-4xl">🍺</p>
                                <p className="text-2xl font-black text-yellow-600">{thirdHalfStats.totalBeerLitros} L</p>
                                <p className="text-[10px] font-bold text-gray-400 uppercase">Bebidos en el período</p>
                            </div>
                            <div className="bg-white dark:bg-gray-900 p-4 rounded-2xl text-center shadow-sm">
                                <p className="text-4xl">💰</p>
                                <p className="text-2xl font-black text-green-600">{formatter.format(thirdHalfStats.totalSpentThirdHalf)}</p>
                                <p className="text-[10px] font-bold text-gray-400 uppercase">Gasto total joda</p>
                            </div>
                        </div>
                    </StatCard>

                    <StatCard title="Máximos Goleadores" icon="⚽">
                        <div className="overflow-x-auto">
                            <table className="w-full text-left">
                                <TableHeader columns={['Jugador', 'Total', 'Jugada', 'Penal', 'Cabeza', 'T. Libre']} />
                                <tbody>
                                    {goalScorers.length > 0 ? goalScorers.map(stat => (
                                        <tr key={stat.player.id} onClick={() => onViewProfile(stat.player)} className="cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800/50">
                                            <td className="p-3 font-bold">{stat.player.nickname}</td>
                                            <td className="p-3 text-center font-black text-xl text-green-600">{stat.totalGoals}</td>
                                            <td className="p-3 text-center">{stat.goalsPlay}</td>
                                            <td className="p-3 text-center">{stat.goalsPenalty}</td>
                                            <td className="p-3 text-center">{stat.goalsHeader}</td>
                                            <td className="p-3 text-center">{stat.goalsSetPiece}</td>
                                        </tr>
                                    )) : <tr><td colSpan={6} className="p-10 text-center italic text-gray-400">No hay goles registrados.</td></tr>}
                                </tbody>
                            </table>
                        </div>
                    </StatCard>
                </div>
            )}

            {view === 'match' && (
                <div className="space-y-6 animate-fadeIn">
                    <select value={selectedMatchId || ''} onChange={(e) => setSelectedMatchId(e.target.value ? Number(e.target.value) : null)} className="w-full p-4 bg-white dark:bg-gray-800 border-2 border-indigo-100 dark:border-indigo-900 rounded-2xl shadow-xl font-bold">
                        <option value="">-- Elige un partido finalizado --</option>
                        {finishedMatches.map(match => (<option key={match.id} value={match.id}>{match.date} - vs {opponents.find(o => o.id === match.opponentId)?.name || 'Rival'}</option>))}
                    </select>
                    {!selectedMatch && <EmptyState message="Selecciona una fecha para ver el resumen." />}
                    {selectedMatch && (
                        <div className="space-y-6 animate-zoomIn">
                            <StatCard title="Goleadores del Encuentro" icon="⚽">
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                    {perMatchStats?.goalScorers.map(p => (
                                        <div key={p.player.id} className="flex justify-between items-center bg-gray-50 dark:bg-gray-900 p-3 rounded-xl border border-gray-100 dark:border-gray-800">
                                            <div className="flex items-center gap-3">
                                                <img src={p.player.photoUrl} className="w-10 h-10 rounded-full" />
                                                <span className="font-bold">{p.player.nickname}</span>
                                            </div>
                                            <span className="bg-green-600 text-white px-3 py-1 rounded-full font-black">⚽ {p.totalGoals}</span>
                                        </div>
                                    ))}
                                </div>
                            </StatCard>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
};