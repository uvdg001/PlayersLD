
import React from 'react';
import type { Player, PlayerMatchStatus } from '../../types.ts';

interface QuickActionOverlayProps {
    player: Player | null;
    onClose: () => void;
    onUpdateStat: (field: keyof PlayerMatchStatus, value: any) => void;
    onUpdatePayment: (amount: number) => void;
}

export const QuickActionOverlay: React.FC<QuickActionOverlayProps> = ({ player, onClose, onUpdateStat, onUpdatePayment }) => {
    if (!player) return null;

    return (
        <div className="fixed inset-0 z-[110] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn" onClick={onClose}>
            <div className="bg-white dark:bg-gray-800 rounded-[2.5rem] w-full max-w-sm overflow-hidden shadow-2xl border-4 border-indigo-500" onClick={e => e.stopPropagation()}>
                <header className="p-6 text-center bg-gray-50 dark:bg-gray-900 border-b dark:border-gray-700">
                    <img src={player.photoUrl} className="w-24 h-24 rounded-full mx-auto border-4 border-white shadow-lg mb-3 object-cover" />
                    <h3 className="text-2xl font-black uppercase tracking-tighter italic text-indigo-600">{player.nickname}</h3>
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Planilla Rápida de Campo</p>
                </header>

                <div className="p-6 grid grid-cols-2 gap-4">
                    <ActionButton icon="⚽" label="+1 GOL" color="bg-green-600" onClick={() => onUpdateStat('goalsPlay', 1)} />
                    <ActionButton icon="👟" label="+1 ASIST" color="bg-blue-600" onClick={() => onUpdateStat('assists', 1)} />
                    <ActionButton icon="🟨" label="AMARILLA" color="bg-yellow-500" onClick={() => onUpdateStat('yellowCards', 1)} />
                    <ActionButton icon="🟥" label="ROJA" color="bg-red-600" onClick={() => onUpdateStat('redCard', true)} />
                    
                    <div className="col-span-2 pt-4 border-t dark:border-gray-700 mt-2">
                        <p className="text-center text-[10px] font-black text-gray-500 uppercase mb-4">Pagos Express</p>
                        <button 
                            onClick={() => onUpdatePayment(1)} 
                            className="w-full py-4 bg-emerald-500 text-white rounded-2xl font-black uppercase italic tracking-tighter shadow-lg active:scale-95 transition-all"
                        >
                            💰 PAGÓ TODO (OK)
                        </button>
                    </div>
                </div>

                <footer className="p-4 bg-gray-50 dark:bg-gray-900 text-center">
                    <button onClick={onClose} className="text-gray-400 font-black uppercase text-xs tracking-widest">Cerrar</button>
                </footer>
            </div>
        </div>
    );
};

const ActionButton: React.FC<{ icon: string, label: string, color: string, onClick: () => void }> = ({ icon, label, color, onClick }) => (
    <button 
        onClick={(e) => { e.stopPropagation(); onClick(); }}
        className={`${color} text-white p-4 rounded-3xl flex flex-col items-center justify-center gap-1 shadow-lg active:scale-90 transition-all`}
    >
        <span className="text-3xl">{icon}</span>
        <span className="text-[10px] font-black uppercase tracking-tighter">{label}</span>
    </button>
);
