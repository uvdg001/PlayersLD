
import React, { useMemo } from 'react';
import type { Player, PlayerMatchStatus, MatchStatus } from '../types.ts';
import { AttendanceStatus, PlayerRole, PaymentStatus } from '../types.ts';
import { AttendanceGridItem } from './AttendanceGridItem.tsx';

interface AttendanceGridProps {
    playerStatuses: PlayerMatchStatus[];
    players: Player[];
    onPlayerStatusChange: (playerId: number, newStatus: AttendanceStatus) => void;
    onPlayerStatsChange: (playerId: number, field: keyof PlayerMatchStatus, value: any) => void;
    currentUser: Player;
    isAdmin: boolean;
    matchStatus?: MatchStatus;
    onViewProfile?: (player: Player) => void;
}

export const AttendanceGrid: React.FC<AttendanceGridProps> = ({ playerStatuses, players, onPlayerStatusChange, onPlayerStatsChange, currentUser, isAdmin, matchStatus, onViewProfile }) => {

    const { staff, sortedFieldPlayers, confirmedCount, doubtfulCount, absentCount } = useMemo(() => {
        
        // Unimos los estados guardados en el partido con los jugadores actuales de la plantilla
        // Esto permite que si agregas un jugador nuevo al club, aparezca como "PENDING" en partidos ya creados
        const allParticipants = players.map(player => {
            const savedStatus = playerStatuses.find(ps => ps.playerId === player.id);
            
            const stats: PlayerMatchStatus = savedStatus || {
                playerId: player.id,
                attendanceStatus: AttendanceStatus.PENDING,
                paymentStatus: PaymentStatus.UNPAID,
                amountPaid: 0,
                quartersPlayed: 4
            };

            return { 
                player, 
                status: stats.attendanceStatus, 
                paymentStatus: stats.paymentStatus, 
                stats 
            };
        });

        const staff = allParticipants.filter(p => p.player!.role === PlayerRole.DT || p.player!.role === PlayerRole.AYUDANTE);
        const fieldPlayers = allParticipants.filter(p => p.player!.role !== PlayerRole.DT && p.player!.role !== PlayerRole.AYUDANTE);

        const statusPriority: Record<AttendanceStatus, number> = {
            [AttendanceStatus.CONFIRMED]: 1,
            [AttendanceStatus.DOUBTFUL]: 2,
            [AttendanceStatus.ABSENT]: 3,
            [AttendanceStatus.PENDING]: 4,
        };

        const sortHybrid = (a: { player: Player, status: AttendanceStatus }, b: { player: Player, status: AttendanceStatus }) => {
            const priorityA = statusPriority[a.status];
            const priorityB = statusPriority[b.status];
            
            if (priorityA !== priorityB) {
                return priorityA - priorityB;
            }

            const nameA = a.player.nickname || a.player.firstName;
            const nameB = b.player.nickname || b.player.firstName;
            return nameA.localeCompare(nameB);
        };

        const sortedFieldPlayers = fieldPlayers.sort(sortHybrid);
        staff.sort(sortHybrid);

        const confirmedCount = fieldPlayers.filter(p => p.status === AttendanceStatus.CONFIRMED).length;
        const doubtfulCount = fieldPlayers.filter(p => p.status === AttendanceStatus.DOUBTFUL).length;
        const absentCount = fieldPlayers.filter(p => p.status === AttendanceStatus.ABSENT).length;
        
        // Si el partido está FINALIZADO, solo mostramos a los que NO estaban en PENDING 
        // para no ver a toda la plantilla en gris en el historial.
        const filteredFieldPlayers = matchStatus === 'FINALIZADO' 
            ? sortedFieldPlayers.filter(p => p.status !== AttendanceStatus.PENDING)
            : sortedFieldPlayers;

        const filteredStaff = matchStatus === 'FINALIZADO'
            ? staff.filter(p => p.status !== AttendanceStatus.PENDING)
            : staff;

        return { 
            staff: filteredStaff, 
            sortedFieldPlayers: filteredFieldPlayers, 
            confirmedCount, 
            doubtfulCount, 
            absentCount 
        };

    }, [playerStatuses, players, matchStatus]);


    const StatusCounter: React.FC<{ label: string; count: number; color: string }> = ({ label, count, color }) => (
        <div className={`text-center p-3 rounded-lg ${color}`}>
            <p className="font-bold text-2xl">{count}</p>
            <p className="text-sm uppercase font-semibold">{label}</p>
        </div>
    );

    return (
        <div className="space-y-6">
            <div className="grid grid-cols-3 gap-4 text-white">
                <StatusCounter label="Confirman" count={confirmedCount} color="bg-green-500" />
                <StatusCounter label="En Duda" count={doubtfulCount} color="bg-yellow-500" />
                <StatusCounter label="No Van" count={absentCount} color="bg-red-500" />
            </div>

            {staff.length > 0 && (
                <div>
                    <h3 className="text-sm font-bold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-3">Cuerpo Técnico</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {staff.map(({ player, stats }) => (
                             <AttendanceGridItem
                                key={player!.id}
                                player={player!}
                                playerStatus={stats}
                                onStatusChange={(newStatus) => onPlayerStatusChange(player!.id, newStatus)}
                                onPlayerStatsChange={onPlayerStatsChange}
                                currentUser={currentUser}
                                isAdmin={isAdmin}
                                matchStatus={matchStatus}
                                onViewProfile={onViewProfile}
                            />
                        ))}
                    </div>
                </div>
            )}

            <div>
                <h3 className="text-sm font-bold uppercase tracking-wider text-gray-500 dark:text-gray-400 mb-3">Jugadores</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {sortedFieldPlayers.map(({ player, stats }) => (
                         <AttendanceGridItem
                            key={player!.id}
                            player={player!}
                            playerStatus={stats}
                            onStatusChange={(newStatus) => onPlayerStatusChange(player!.id, newStatus)}
                            onPlayerStatsChange={onPlayerStatsChange}
                            currentUser={currentUser}
                            isAdmin={isAdmin}
                            matchStatus={matchStatus}
                            onViewProfile={onViewProfile}
                        />
                    ))}
                </div>
            </div>
        </div>
    );
};
