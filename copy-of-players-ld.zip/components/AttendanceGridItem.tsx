
import React, { useState } from 'react';
import type { Player, MatchStatus, PlayerMatchStatus } from '../types.ts';
import { AttendanceStatus, PaymentStatus, PlayerRole } from '../types.ts';
import { StarRating } from './StarRating.tsx';

interface AttendanceGridItemProps {
    player: Player;
    playerStatus: PlayerMatchStatus;
    onStatusChange: (newStatus: AttendanceStatus) => void;
    onPlayerStatsChange: (playerId: number, field: keyof PlayerMatchStatus, value: any) => void;
    currentUser: Player;
    isAdmin: boolean;
    matchStatus?: MatchStatus;
    onViewProfile?: (player: Player) => void;
}

const StatusButton: React.FC<{ icon: string; label: string; isSelected: boolean; onClick: () => void; disabled: boolean; }> = ({ icon, label, isSelected, onClick, disabled }) => (
    <button onClick={(e) => { e.preventDefault(); onClick(); }} disabled={disabled} className={`w-12 h-12 flex items-center justify-center rounded-full text-2xl transition-all duration-200 ${isSelected ? 'ring-2 ring-black dark:ring-white' : 'bg-gray-200 dark:bg-gray-600 opacity-60'} ${disabled ? 'cursor-not-allowed' : 'hover:opacity-100'}`} title={label}>
        <div className={`w-8 h-8 rounded-md flex items-center justify-center ${isSelected ? (label === 'Confirmar' ? 'bg-green-500' : label === 'En Duda' ? 'bg-yellow-500' : label === 'Ausente' ? 'bg-red-500' : 'bg-gray-400') : 'bg-transparent border border-gray-400'}`}>
            <span className={isSelected ? 'text-white' : ''}>{icon}</span>
        </div>
    </button>
);

const StatControl: React.FC<{ icon: string; value: number; onUpdate: (newValue: number) => void; max?: number, title: string, colorClass?: string }> = ({ icon, value, onUpdate, max, title, colorClass }) => (
    <div className={`flex items-center space-x-1 p-1 rounded-md ${colorClass || 'bg-gray-200 dark:bg-gray-600'}`} title={title}>
        <span className="text-lg">{icon}</span>
        <button onClick={() => onUpdate(value - 1)} disabled={value <= 0} className="px-1 disabled:opacity-50 font-bold hover:bg-black/10 rounded">-</button>
        <span className="w-5 text-center font-bold text-sm">{value}</span>
        <button onClick={() => onUpdate(value + 1)} disabled={max !== undefined && value >= max} className="px-1 disabled:opacity-50 font-bold hover:bg-black/10 rounded">+</button>
    </div>
);


export const AttendanceGridItem: React.FC<AttendanceGridItemProps> = ({ player, playerStatus, onStatusChange, onPlayerStatsChange, currentUser, isAdmin, matchStatus, onViewProfile }) => {
    const [imgError, setImgError] = useState(false);
    const isInteractive = isAdmin || (currentUser.id === player.id && matchStatus !== 'FINALIZADO');
    const isStaff = player.role === PlayerRole.DT || player.role === PlayerRole.AYUDANTE;
    const status = playerStatus.attendanceStatus;
    const paymentStatus = playerStatus.paymentStatus;

    const handleStatChange = (field: keyof PlayerMatchStatus, value: number) => {
        if (value < 0) value = 0;
        onPlayerStatsChange(player.id, field, value);
    };

    const handleRedCardToggle = () => {
        onPlayerStatsChange(player.id, 'redCard', !playerStatus.redCard);
    };

    const handleStatusClick = (clickedStatus: AttendanceStatus) => {
        if (status === clickedStatus) {
            onStatusChange(AttendanceStatus.PENDING);
        } else {
            onStatusChange(clickedStatus);
        }
    };

    const statusStyles = {
        [AttendanceStatus.CONFIRMED]: { bg: 'bg-green-100 dark:bg-green-900/40', border: 'border-green-500' },
        [AttendanceStatus.DOUBTFUL]: { bg: 'bg-yellow-100 dark:bg-yellow-900/40', border: 'border-yellow-500' },
        [AttendanceStatus.ABSENT]: { bg: 'bg-red-100 dark:bg-red-900/40', border: 'border-red-500' },
        [AttendanceStatus.PENDING]: { bg: 'bg-gray-100 dark:bg-gray-700/50', border: 'border-gray-400' },
    }[status];

    const paymentColor = paymentStatus === PaymentStatus.PAID ? 'bg-green-500' : paymentStatus === PaymentStatus.PARTIAL ? 'bg-yellow-500' : 'bg-red-500';

    const cardBorderColor = isStaff ? 'border-black dark:border-white' : statusStyles.border;
    const imageBorderColor = isStaff ? 'border-black' : statusStyles.border;

    return (
        <div className={`p-4 rounded-3xl shadow-md border-2 relative transition-all ${statusStyles.bg} ${cardBorderColor}`}>
            {status === AttendanceStatus.CONFIRMED && !isStaff && (
                <div className={`absolute top-3 right-3 w-6 h-6 rounded-full ${paymentColor} border-2 border-white shadow-sm flex items-center justify-center text-[10px] text-white font-black`} title="Estado de Pago">
                    $
                </div>
            )}
            <div className="flex flex-col items-center gap-3">
                 <div className="relative group cursor-pointer" onDoubleClick={() => onViewProfile && onViewProfile(player)}>
                    {player.photoUrl && !imgError ? (
                        <img 
                            src={player.photoUrl} 
                            onError={() => setImgError(true)}
                            className={`w-44 h-44 rounded-full object-cover border-[6px] ${imageBorderColor} transform transition-transform duration-200 hover:scale-105 active:scale-95 shadow-xl`} 
                            alt="" 
                            title="Doble click para ver estadísticas"
                        />
                    ) : (
                        <div className={`w-44 h-44 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center border-[6px] ${imageBorderColor} shadow-xl text-6xl`}>
                            👤
                        </div>
                    )}
                     {!isStaff && player.jerseyNumber && (
                        <div className="absolute -bottom-1 -right-1 bg-gray-900 text-white w-10 h-10 rounded-full flex items-center justify-center text-lg font-black border-4 border-white shadow-lg">
                            {player.jerseyNumber}
                        </div>
                    )}
                </div>
                <div className="text-center w-full">
                     <p className="font-black text-2xl truncate cursor-pointer hover:underline text-gray-900 dark:text-gray-100 tracking-tighter" onClick={() => onViewProfile && onViewProfile(player)}>
                        {player.nickname}
                     </p>
                     
                     {isStaff ? (
                        <div className="mt-1">
                            <span className="inline-block px-4 py-1 text-xs font-black rounded-full uppercase tracking-widest shadow-sm bg-black dark:bg-white dark:text-black">
                                {player.role === PlayerRole.DT ? 'DIRECTOR TÉCNICO' : 'AYUDANTE DE CAMPO'}
                            </span>
                        </div>
                     ) : (
                         <div className="flex justify-center mt-1">
                             <StarRating rating={player.skillLevel} size="text-sm" />
                         </div>
                     )}
                </div>
                 <div className="flex justify-center space-x-4 mt-2">
                    <StatusButton icon="✓" label="Confirmar" isSelected={status === AttendanceStatus.CONFIRMED} onClick={() => handleStatusClick(AttendanceStatus.CONFIRMED)} disabled={!isInteractive} />
                    <StatusButton icon="?" label="En Duda" isSelected={status === AttendanceStatus.DOUBTFUL} onClick={() => handleStatusClick(AttendanceStatus.DOUBTFUL)} disabled={!isInteractive} />
                    <StatusButton icon="✕" label="Ausente" isSelected={status === AttendanceStatus.ABSENT} onClick={() => handleStatusClick(AttendanceStatus.ABSENT)} disabled={!isInteractive} />
                </div>
            </div>

            {/* ADMIN STATS CONTROLS */}
            {isAdmin && playerStatus.attendanceStatus === AttendanceStatus.CONFIRMED && !isStaff && (
                <div className="mt-5 pt-4 border-t border-gray-200 dark:border-gray-600 space-y-4">
                    <div>
                        <h4 className="text-[10px] font-black text-gray-400 uppercase mb-2 tracking-widest text-center">Goles y Aportes</h4>
                        <div className="flex flex-wrap justify-center items-center gap-2">
                            <StatControl title="Gol de Jugada" icon="⚽" value={playerStatus.goalsPlay || 0} onUpdate={(v) => handleStatChange('goalsPlay', v)} />
                            <StatControl title="Gol de Cabeza" icon="🧠" value={playerStatus.goalsHeader || 0} onUpdate={(v) => handleStatChange('goalsHeader', v)} />
                            <StatControl title="Gol de Penal" icon="🎯" value={playerStatus.goalsPenalty || 0} onUpdate={(v) => handleStatChange('goalsPenalty', v)} />
                            <StatControl title="Gol de Tiro Libre" icon="👟" value={playerStatus.goalsSetPiece || 0} onUpdate={(v) => handleStatChange('goalsSetPiece', v)} />
                            <StatControl title="Asistencia" icon="🅰️" value={playerStatus.assists || 0} onUpdate={(v) => handleStatChange('assists', v)} colorClass="bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-200" />
                        </div>
                    </div>
                     <div>
                        <h4 className="text-[10px] font-black text-gray-400 uppercase mb-2 tracking-widest text-center">Errores y Tarjetas</h4>
                        <div className="flex flex-wrap justify-center items-center gap-2">
                            <StatControl title="Gol en Contra" icon="🥅" value={playerStatus.ownGoals || 0} onUpdate={(v) => handleStatChange('ownGoals', v)} colorClass="bg-red-100 dark:bg-red-900/30" />
                            <StatControl title="Penal Errado" icon="❌" value={playerStatus.penaltiesMissed || 0} onUpdate={(v) => handleStatChange('penaltiesMissed', v)} colorClass="bg-red-100 dark:bg-red-900/30" />
                            <div className="w-px h-6 bg-gray-300 dark:bg-gray-500 mx-1"></div>
                            <StatControl title="Amarillas" icon="🟨" value={playerStatus.yellowCards || 0} onUpdate={(v) => handleStatChange('yellowCards', v)} max={2} colorClass="bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800" />
                            <button onClick={handleRedCardToggle} className={`flex items-center space-x-1 px-3 py-1 rounded-md border-2 transition-all ${playerStatus.redCard ? 'bg-red-600 border-red-700 text-white' : 'bg-gray-100 border-gray-300 text-gray-400'}`} title="Tarjeta Roja">
                                <span className="text-lg">🟥</span>
                                <span className="font-bold text-sm">{playerStatus.redCard ? '1' : '0'}</span>
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};
