// Juego eliminado
export const LDPenalties = () => null;