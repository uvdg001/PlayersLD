import React, { useState, useEffect, useMemo } from 'react';
import type { Match, ThirdHalfItem, Opponent, Player, ThirdHalf } from '../../types.ts';
import { AttendanceStatus } from '../../types.ts';
import { useToast } from '../../hooks/useToast.ts';

interface ThirdHalfPageProps {
    matches: Match[];
    opponents: Opponent[];
    players: Player[]; 
    onUpdateThirdHalf: (matchId: number, items: ThirdHalfItem[], payerIds?: number[]) => void;
    initialMatchId?: number | null;
}

const PRESET_ITEMS = [
    { id: 'beer', name: 'Cerveza (Litros)', emoji: '🍺', defaultPrice: 4000 },
    { id: 'fernet', name: 'Fernet (Botella)', emoji: '🍷', defaultPrice: 12000 },
    { id: 'pizza', name: 'Pizzas', emoji: '🍕', defaultPrice: 8000 },
    { id: 'asado', name: 'Asado (Kg)', emoji: '🥩', defaultPrice: 15000 },
    { id: 'ice', name: 'Bolsa Hielo', emoji: '🧊', defaultPrice: 2000 },
    { id: 'soda', name: 'Gaseosa (2.5L)', emoji: '🥤', defaultPrice: 3500 },
    { id: 'chips', name: 'Papas/Snacks', emoji: '🍟', defaultPrice: 2500 },
    { id: 'other', name: 'Varios', emoji: '🛒', defaultPrice: 1000 },
];

export const ThirdHalfPage: React.FC<ThirdHalfPageProps> = ({ matches, opponents, players, onUpdateThirdHalf, initialMatchId }) => {
    const toast = useToast();
    const [selectedMatchId, setSelectedMatchId] = useState<number | null>(null);
    const [items, setItems] = useState<ThirdHalfItem[]>([]);
    const [payerIds, setPayerIds] = useState<number[]>([]);
    const [splitCount, setSplitCount] = useState(1);

    useEffect(() => {
        if (initialMatchId) setSelectedMatchId(initialMatchId);
    }, [initialMatchId]);

    const finishedMatches = matches
        .filter(m => m.status === 'FINALIZADO')
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    const selectedMatch = matches.find(m => m.id === selectedMatchId);

    const confirmedPlayers = useMemo(() => {
        if (!selectedMatch) return [];
        return players.filter(p => selectedMatch.playerStatuses.some(ps => ps.playerId === p.id && ps.attendanceStatus === AttendanceStatus.CONFIRMED));
    }, [selectedMatch, players]);

    useEffect(() => {
        if (selectedMatch) {
            const data: ThirdHalf | undefined = selectedMatch.thirdHalf;
            const existing = data?.items || [];
            const merged = PRESET_ITEMS.map(preset => {
                const found = existing.find(e => e.id === preset.id);
                return found || { id: preset.id, name: preset.name, quantity: 0, unitPrice: preset.defaultPrice, total: 0 };
            });
            setItems(merged);
            setPayerIds(data?.completedPayerIds || []);
            setSplitCount(confirmedPlayers.length || 1);
        }
    }, [selectedMatchId, selectedMatch, confirmedPlayers.length]);

    const handleQuantityChange = (id: string, delta: number) => {
        setItems(prev => prev.map(item => {
            if (item.id === id) {
                const newQ = Math.max(0, item.quantity + delta);
                return { ...item, quantity: newQ, total: newQ * item.unitPrice };
            }
            return item;
        }));
    };

    const togglePayer = (pid: number) => {
        setPayerIds(prev => prev.includes(pid) ? prev.filter(id => id !== pid) : [...prev, pid]);
    };

    const handleSave = () => {
        if (!selectedMatchId) return;
        const activeItems = items.filter(i => i.quantity > 0);
        onUpdateThirdHalf(selectedMatchId, activeItems, payerIds);
        toast.success("¡Datos guardados! 🍻");
    };

    const totalSpent = items.reduce((sum, item) => sum + item.total, 0);
    const amountPerPerson = splitCount > 0 ? totalSpent / splitCount : 0;
    const formatter = new Intl.NumberFormat('es-AR', { style: 'currency', currency: 'ARS' });

    if (!selectedMatchId) {
        return (
            <div className="bg-white dark:bg-gray-800 rounded-3xl shadow-2xl p-6 md:p-10 min-h-[60vh] border-t-8 border-yellow-500">
                <h2 className="text-4xl font-black text-center text-gray-800 dark:text-gray-100 mb-2 uppercase italic tracking-tighter">Cervezocracia</h2>
                <p className="text-center text-gray-400 font-bold uppercase text-xs tracking-widest mb-10">Control de consumo y deudores</p>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {finishedMatches.map(m => {
                         const opp = opponents.find(o => o.id === m.opponentId)?.name || 'Rival';
                         const hasData = m.thirdHalf && m.thirdHalf.totalSpent > 0;
                         return (
                            <button key={m.id} onClick={() => setSelectedMatchId(m.id)} className={`p-6 rounded-2xl border-4 text-left transition-all hover:scale-105 active:scale-95 ${hasData ? 'bg-indigo-50 border-indigo-200 dark:bg-indigo-900/30' : 'bg-gray-50 border-gray-100 dark:bg-gray-700/50'}`}>
                                <p className="text-[10px] font-black text-gray-400 uppercase mb-1">{m.date}</p>
                                <h3 className="font-black text-xl text-indigo-900 dark:text-white mb-2 italic uppercase tracking-tighter">vs {opp}</h3>
                                {hasData ? <span className="text-green-600 font-black text-lg">{formatter.format(m.thirdHalf!.totalSpent)}</span> : <span className="text-gray-400 text-xs font-bold uppercase italic tracking-widest">Sin datos</span>}
                            </button>
                         )
                    })}
                </div>
            </div>
        );
    }

    return (
        <div className="bg-white dark:bg-gray-800 rounded-3xl shadow-2xl p-6 md:p-10 border-t-8 border-yellow-500 animate-fadeIn">
            <button onClick={() => setSelectedMatchId(null)} className="mb-6 font-black text-xs text-gray-400 hover:text-indigo-600 uppercase tracking-widest">← Elegir otro partido</button>
            
            <div className="flex flex-col lg:flex-row gap-10">
                <div className="flex-1 space-y-6">
                    <div className="bg-yellow-50 dark:bg-yellow-900/10 p-6 rounded-3xl border-2 border-yellow-100 dark:border-yellow-900/50">
                        <h3 className="text-2xl font-black italic uppercase tracking-tighter mb-6 flex items-center gap-2">
                            <span>🛒</span> Ticket de Consumo
                        </h3>
                        <div className="space-y-3">
                            {items.map(item => (
                                <div key={item.id} className="flex items-center justify-between p-3 bg-white dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-800 shadow-sm">
                                    <div className="flex items-center gap-3">
                                        <span className="text-2xl">{PRESET_ITEMS.find(p => p.id === item.id)?.emoji}</span>
                                        <span className="font-bold text-gray-700 dark:text-gray-300 text-sm">{item.name}</span>
                                    </div>
                                    <div className="flex items-center gap-3">
                                        <button onClick={() => handleQuantityChange(item.id, -1)} className="w-8 h-8 rounded-full bg-gray-100 text-gray-400 font-black">-</button>
                                        <span className="w-6 text-center font-black text-lg">{item.quantity}</span>
                                        <button onClick={() => handleQuantityChange(item.id, 1)} className="w-8 h-8 rounded-full bg-yellow-400 text-black font-black">+</button>
                                    </div>
                                </div>
                            ))}
                        </div>
                        <div className="mt-8 pt-6 border-t-2 border-dashed border-yellow-200 dark:border-yellow-900 flex justify-between items-center">
                            <span className="font-black text-gray-400 uppercase text-xs">Total Gastado:</span>
                            <span className="text-3xl font-black text-green-600">{formatter.format(totalSpent)}</span>
                        </div>
                    </div>
                </div>

                <div className="lg:w-96 space-y-6">
                    <div className="bg-indigo-950 p-6 rounded-3xl text-white shadow-xl relative overflow-hidden">
                        <div className="absolute -right-5 -bottom-5 text-8xl opacity-10">💸</div>
                        <p className="text-[10px] font-black text-indigo-300 uppercase tracking-widest mb-1">Cálculo por Pera</p>
                        <h4 className="text-3xl font-black italic uppercase tracking-tighter">{formatter.format(amountPerPerson)}</h4>
                        <p className="text-xs text-indigo-400 mt-2 font-bold uppercase">Dividido entre {splitCount} presentes</p>
                    </div>

                    <div className="bg-gray-50 dark:bg-gray-900 rounded-3xl p-6 border-2 border-gray-100 dark:border-gray-800">
                        <h3 className="font-black uppercase tracking-tighter text-lg mb-4 text-gray-800 dark:text-white flex items-center gap-2">
                            <span>✅</span> Lista de Pagos
                        </h3>
                        <div className="space-y-2 max-h-96 overflow-y-auto pr-2 custom-scrollbar">
                            {confirmedPlayers.map(p => {
                                const hasPaid = payerIds.includes(p.id);
                                return (
                                    <button 
                                        key={p.id} 
                                        onClick={() => togglePayer(p.id)}
                                        className={`w-full flex items-center justify-between p-3 rounded-2xl border-2 transition-all ${hasPaid ? 'bg-green-50 border-green-500 text-green-700' : 'bg-white dark:bg-gray-800 border-gray-100 dark:border-gray-700 text-gray-500'}`}
                                    >
                                        <div className="flex items-center gap-3">
                                            <img src={p.photoUrl} className={`w-8 h-8 rounded-full object-cover ${!hasPaid && 'grayscale opacity-50'}`} alt="" />
                                            <span className="font-bold text-sm">{p.nickname}</span>
                                        </div>
                                        <span className={`text-lg ${hasPaid ? 'opacity-100' : 'opacity-20'}`}>💰</span>
                                    </button>
                                );
                            })}
                        </div>
                    </div>

                    <button onClick={handleSave} className="w-full py-5 bg-indigo-600 hover:bg-indigo-700 text-white font-black rounded-3xl shadow-xl shadow-indigo-500/30 transition-all transform active:scale-95 flex items-center justify-center gap-3">
                        <span>💾</span> GUARDAR TODO
                    </button>
                </div>
            </div>
        </div>
    );
};