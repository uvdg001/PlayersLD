
import React from 'react';
import type { Match } from '../../types.ts';

interface TreasuryData {
    totalSpent: number;
    totalCollected: number;
    balance: number;
    matches: (Match & { collected: number, balance: number })[];
}

interface TreasuryPageProps {
    data: TreasuryData;
}

const formatter = new Intl.NumberFormat('es-AR', { style: 'currency', currency: 'ARS', maximumFractionDigits: 0 });

const SummaryCard: React.FC<{ title: string, value: number, colorClass: string }> = ({ title, value, colorClass }) => (
    <div className="bg-gray-100 dark:bg-gray-700 p-4 rounded-lg text-center shadow-sm">
        <p className="text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase">{title}</p>
        <p className={`text-2xl font-black ${colorClass}`}>{formatter.format(value)}</p>
    </div>
);

export const TreasuryPage: React.FC<TreasuryPageProps> = ({ data }) => {
    return (
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 space-y-8">
            <h2 className="text-3xl font-bold text-center text-gray-800 dark:text-gray-100">Tesorería del Equipo</h2>
            
            <div>
                <h3 className="text-xl font-bold mb-4 text-gray-700 dark:text-gray-200">Balance por Partido</h3>
                <div className="overflow-x-auto border dark:border-gray-700 rounded-lg shadow-sm">
                    <table className="w-full text-left">
                        <thead className="bg-gray-200 dark:bg-gray-900 text-gray-700 dark:text-gray-300">
                            <tr>
                                <th className="p-3 text-sm font-bold tracking-wide">Fecha</th>
                                <th className="p-3 text-sm font-bold tracking-wide text-right">Costo Cancha</th>
                                <th className="p-3 text-sm font-bold tracking-wide text-right">Recaudado</th>
                                <th className="p-3 text-sm font-bold tracking-wide text-right">Estado</th>
                                <th className="p-3 text-sm font-bold tracking-wide text-right">Diferencia</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200 dark:divide-gray-700 bg-white dark:bg-gray-800">
                            {data.matches.length > 0 ? data.matches.map(match => {
                                const isCovered = match.balance >= 0;
                                return (
                                    <tr key={match.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                                        <td className="p-3 text-sm">
                                            <span className="font-bold block">{match.date}</span>
                                            {match.tournamentRound && <span className="text-xs text-gray-500">Fecha {match.tournamentRound}</span>}
                                        </td>
                                        <td className="p-3 text-sm text-right font-medium">{formatter.format(match.courtFee)}</td>
                                        <td className="p-3 text-sm text-right font-medium text-blue-600 dark:text-blue-400">{formatter.format(match.collected)}</td>
                                        <td className="p-3 text-sm text-right">
                                            {isCovered ? (
                                                <span className="px-2 py-1 rounded-full bg-green-100 text-green-800 text-xs font-bold">✅ Cubierto</span>
                                            ) : (
                                                <span className="px-2 py-1 rounded-full bg-red-100 text-red-800 text-xs font-bold">❌ Déficit</span>
                                            )}
                                        </td>
                                        <td className={`p-3 text-sm font-bold text-right ${isCovered ? 'text-green-600' : 'text-red-600'}`}>
                                            {formatter.format(match.balance)}
                                        </td>
                                    </tr>
                                );
                            }) : (
                                <tr>
                                    <td colSpan={5} className="text-center py-8 text-gray-500 dark:text-gray-400">
                                        No hay partidos finalizados para mostrar.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            <div className="pt-8 border-t-2 border-dashed border-gray-300 dark:border-gray-600">
                <h3 className="text-xl font-bold mb-4 text-gray-700 dark:text-gray-200">Resumen General Acumulado</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <SummaryCard title="Total Gastado (Canchas)" value={data.totalSpent} colorClass="text-red-600 dark:text-red-400" />
                    <SummaryCard title="Total Recaudado" value={data.totalCollected} colorClass="text-green-600 dark:text-green-400" />
                    <div className={`p-4 rounded-lg text-center shadow-md border-2 ${data.balance >= 0 ? 'bg-green-50 border-green-500 dark:bg-green-900/30' : 'bg-red-50 border-red-500 dark:bg-red-900/30'}`}>
                        <p className="text-sm font-bold uppercase text-gray-600 dark:text-gray-300">Saldo Final</p>
                        <p className={`text-3xl font-black ${data.balance >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                            {formatter.format(data.balance)}
                        </p>
                        <p className="text-xs mt-1 font-semibold opacity-70">
                            {data.balance >= 0 ? '¡Las cuentas cierran!' : '¡Falta plata!'}
                        </p>
                    </div>
                </div>
            </div>

        </div>
    );
};
