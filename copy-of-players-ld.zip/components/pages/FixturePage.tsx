
import React from 'react';
import type { Tournament, Match, Opponent, MyTeam, Page, Venue } from '../../types.ts';

interface FixturePageProps {
    tournaments: Tournament[];
    myTeam: MyTeam | null;
    matches: Match[];
    opponents: Opponent[];
    venues: Venue[];
    setCurrentPage: (page: Page) => void;
    setSelectedMatchId: (id: number) => void;
    onOpenMatchForm: (params: { tournamentId: number, match?: Match }) => void;
    onDeleteMatch: (matchId: number) => void;
    isAdmin: boolean;
}

const MatchStatusBadge: React.FC<{ status?: string }> = ({ status }) => {
    const styles: { [key: string]: string } = {
        'PROGRAMADO': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
        'FINALIZADO': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
        'SUSPENDIDO': 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300',
    };
    return (
        <span className={`px-2 py-1 text-[10px] font-black uppercase rounded-md border ${styles[status || ''] || 'bg-gray-100 text-gray-800'}`}>
            {status?.replace('_', ' ')}
        </span>
    );
};


export const FixturePage: React.FC<FixturePageProps> = ({ tournaments, myTeam, matches, opponents, setCurrentPage, setSelectedMatchId, onOpenMatchForm, onDeleteMatch, isAdmin }) => {
    
    const sortedTournaments = [...tournaments].sort((a, b) => b.year - a.year);

    const getOpponentName = (opponentId?: number): string => {
        const opponent = opponents.find(o => o.id === opponentId);
        return opponent ? opponent.name : "Rival a definir";
    };
    
    const myTeamScore = (match: Match) => matches.find(m => m.id === match.id)?.playerStatuses.reduce((total, ps) => total + (ps.goalsPlay || 0) + (ps.goalsPenalty || 0) + (ps.goalsHeader || 0) + (ps.goalsSetPiece || 0), 0) ?? 0;

    const confirmDelete = (matchId: number, e: React.MouseEvent) => {
        e.stopPropagation();
        const confirmation = window.prompt("⚠️ ¿Borrar partido permanentemente?\nEscribe: ELIMINAR");
        if (confirmation === "ELIMINAR") onDeleteMatch(matchId);
    };

    const handleMatchClick = (matchId: number) => {
        setSelectedMatchId(matchId);
        setCurrentPage('home');
    };

    return (
        <div className="bg-white dark:bg-gray-800 rounded-3xl shadow-2xl p-6 md:p-8 space-y-8 border-t-8 border-indigo-600">
            <h2 className="text-4xl font-black text-center text-gray-800 dark:text-white uppercase tracking-tighter italic">Fixture Oficial</h2>

            {sortedTournaments.length > 0 ? (
                sortedTournaments.map(tournament => {
                    const tournamentMatches = matches
                        .filter(m => m.tournamentId === tournament.id)
                        .sort((a, b) => (a.tournamentRound || 0) - (b.tournamentRound || 0));
                    const isFinished = tournament.status === 'FINALIZADO';

                    return (
                        <div key={tournament.id} className={`p-6 border-2 dark:border-gray-700 rounded-3xl ${isFinished ? 'bg-gray-50/50 dark:bg-gray-900/20 opacity-80' : 'bg-white dark:bg-gray-800'}`}>
                            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
                                <div>
                                    <h3 className="text-2xl font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-tight">{tournament.name} <span className="text-gray-400">'{tournament.year % 100}</span></h3>
                                    <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">{tournament.description}</p>
                                </div>
                                {isAdmin && !isFinished && (
                                    <button onClick={() => onOpenMatchForm({ tournamentId: tournament.id })} className="px-6 py-2 bg-indigo-600 text-white text-xs font-black uppercase rounded-full shadow-lg hover:bg-indigo-700 transition-all active:scale-95">
                                        + Nueva Fecha
                                    </button>
                                )}
                            </div>
                            
                            {tournamentMatches.length > 0 ? (
                                <div className="grid gap-4">
                                    {tournamentMatches.map(match => (
                                        <div 
                                            key={match.id} 
                                            onClick={() => handleMatchClick(match.id)}
                                            className="group flex flex-col md:flex-row items-center justify-between p-5 bg-gray-50 dark:bg-gray-900/50 rounded-2xl border-2 border-transparent hover:border-indigo-500/30 transition-all cursor-pointer relative overflow-hidden"
                                        >
                                            <div className="flex flex-col md:flex-row items-center gap-6 w-full">
                                                <div className="flex flex-col items-center md:items-start min-w-[80px]">
                                                    <span className="text-xl font-black text-indigo-600">F{match.tournamentRound || '-'}</span>
                                                    <MatchStatusBadge status={match.status} />
                                                </div>

                                                <div className="flex-1 flex items-center justify-center gap-4 w-full">
                                                    <span className="text-sm font-black uppercase text-gray-400 md:w-32 text-right truncate hidden md:block">{myTeam?.name}</span>
                                                    
                                                    {match.status === 'FINALIZADO' ? (
                                                        <div className="flex items-center bg-black px-4 py-2 rounded-lg font-mono text-2xl shadow-inner border border-gray-800">
                                                            <span className="text-yellow-400 font-black">{myTeamScore(match)}</span>
                                                            <span className="text-gray-600 mx-2">:</span>
                                                            <span className="text-yellow-400 font-black">{match.opponentScore ?? 0}</span>
                                                        </div>
                                                    ) : (
                                                        <div className="px-4 py-2 rounded-lg bg-gray-200 dark:bg-gray-800 font-black text-gray-500 uppercase text-xs tracking-tighter">VS</div>
                                                    )}

                                                    <span className="text-sm font-black uppercase text-gray-800 dark:text-white md:w-32 text-left truncate">{getOpponentName(match.opponentId)}</span>
                                                </div>

                                                <div className="text-center md:text-right">
                                                    <p className="text-xs font-black text-gray-400 uppercase tracking-widest">{match.date.split(',')[0]}</p>
                                                    <p className="text-sm font-bold text-gray-600 dark:text-gray-300">{match.time} HS • {match.location}</p>
                                                </div>
                                            </div>

                                            {isAdmin && (
                                                <div className="flex md:flex-col gap-2 mt-4 md:mt-0 md:ml-4">
                                                    <button onClick={(e) => { e.stopPropagation(); onOpenMatchForm({ tournamentId: tournament.id, match: match }); }} className="p-2 bg-white dark:bg-gray-800 rounded-full shadow-sm hover:text-indigo-600"><svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z" /></svg></button>
                                                    <button onClick={(e) => confirmDelete(match.id, e)} className="p-2 bg-white dark:bg-gray-800 rounded-full shadow-sm hover:text-red-600"><svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" /></svg></button>
                                                </div>
                                            )}
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <p className="text-sm text-gray-500 italic text-center py-4">No hay fechas programadas aún.</p>
                            )}
                        </div>
                    );
                })
            ) : (
                 <div className="text-center py-20 bg-gray-50 dark:bg-gray-900/50 rounded-3xl border-4 border-dashed border-gray-200 dark:border-gray-800">
                    <span className="text-6xl mb-4 block">⚽</span>
                    <h3 className="text-xl font-black text-gray-400 uppercase tracking-tighter">Sin Torneos Activos</h3>
                    {isAdmin && <p className="text-xs text-indigo-500 font-bold mt-2">Ve a la pestaña "Torneos" para crear el primero.</p>}
                </div>
            )}
        </div>
    );
};
