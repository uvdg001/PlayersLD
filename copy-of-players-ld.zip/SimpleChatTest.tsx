
import React, { useState, useEffect, useRef } from 'react';
import firebase from 'firebase/compat/app';
import 'firebase/compat/firestore';

// --- CONFIGURACIÓN DE FIREBASE ---
const firebaseConfig = {
  apiKey: (import.meta as any).env.VITE_FIREBASE_API_KEY,
  authDomain: (import.meta as any).env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: (import.meta as any).env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: (import.meta as any).env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: (import.meta as any).env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: (import.meta as any).env.VITE_FIREBASE_APP_ID,
};

// Inicialización segura
if (!firebase.apps.length) {
  try {
    firebase.initializeApp(firebaseConfig);
    console.log("Firebase inicializado correctamente en prueba.");
  } catch (err) {
    console.error("Error inicializando Firebase:", err);
  }
}
const db = firebase.firestore();

const SimpleChatTest: React.FC = () => {
  const [user, setUser] = useState<string | null>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [inputText, setInputText] = useState('');
  const [error, setError] = useState<string | null>(null);
  const dummyDiv = useRef<HTMLDivElement>(null);

  // Suscripción
  useEffect(() => {
    if (!db) {
        setError("Firebase no se pudo inicializar. Revisa tu archivo .env");
        return;
    }

    const unsubscribe = db.collection('test_chat_simple')
      .orderBy('timestamp', 'asc')
      .onSnapshot(
        (snapshot) => {
          const msgs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
          setMessages(msgs);
          setTimeout(() => dummyDiv.current?.scrollIntoView({ behavior: 'smooth' }), 100);
        },
        (err) => {
          console.error("Error de conexión:", err);
          setError(`Error de conexión: ${err.message}. Revisa la consola.`);
        }
      );

    return () => unsubscribe();
  }, []);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || !user) return;

    try {
      await db.collection('test_chat_simple').add({
        text: inputText,
        sender: user,
        timestamp: Date.now(),
        dateString: new Date().toLocaleTimeString()
      });
      setInputText('');
    } catch (err: any) {
      setError("Error al enviar: " + err.message);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="bg-white p-8 rounded shadow-lg max-w-sm w-full text-center">
          <h1 className="text-2xl font-bold mb-4 text-blue-600">Prueba de Chat</h1>
          {error && <div className="bg-red-100 text-red-700 p-2 rounded mb-4 text-sm">{error}</div>}
          <p className="mb-6">Elige un usuario para probar la conexión:</p>
          <div className="space-y-3">
            <button onClick={() => setUser('Usuario A')} className="w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-600">Soy Usuario A</button>
            <button onClick={() => setUser('Usuario B')} className="w-full bg-green-500 text-white py-2 rounded hover:bg-green-600">Soy Usuario B</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-gray-100 max-w-md mx-auto border-x border-gray-300">
      <div className="bg-white p-4 shadow flex justify-between items-center">
        <div>
            <h2 className="font-bold">Chat Test</h2>
            <p className="text-xs text-gray-500">Conectado como: {user}</p>
        </div>
        <button onClick={() => setUser(null)} className="text-red-500 text-sm">Salir</button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {error && <div className="bg-red-100 text-red-700 p-2 rounded text-sm text-center">{error}</div>}
        {messages.length === 0 && !error && <p className="text-center text-gray-400 mt-10">No hay mensajes. ¡Escribe algo!</p>}
        
        {messages.map((msg) => {
          const isMe = msg.sender === user;
          return (
            <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
              <div className={`px-4 py-2 rounded-lg max-w-[80%] ${isMe ? 'bg-blue-500 text-white' : 'bg-white border text-gray-800'}`}>
                <p className="text-xs opacity-75 mb-0.5">{msg.sender}</p>
                <p>{msg.text}</p>
              </div>
            </div>
          );
        })}
        <div ref={dummyDiv} />
      </div>

      <form onSubmit={handleSend} className="p-3 bg-white border-t flex gap-2">
        <input
          className="flex-1 border rounded px-3 py-2"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="Escribe aquí..."
          autoFocus
        />
        <button type="submit" disabled={!inputText.trim()} className="bg-blue-600 text-white px-4 py-2 rounded font-bold disabled:opacity-50">
          Enviar
        </button>
      </form>
    </div>
  );
};

export default SimpleChatTest;
