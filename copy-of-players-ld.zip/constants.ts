import React, { lazy } from 'react';
import type { Player, MyTeam, AppSettings, GameIdea } from './types.ts';
import { PlayerRole } from './types.ts';

export interface GameCatalogItem {
    id: string;
    title: string;
    description: string;
    icon: string;
    color: string;
    component: React.LazyExoticComponent<React.FC<any>>;
    isTrivia?: boolean;
    triviaMode?: 'CALENDAR' | 'SCOUT' | 'RADIO';
}

// Registro de Juegos para Lazy Loading - Versión Limpia
export const GAME_CATALOG: GameCatalogItem[] = [
    { 
        id: 'SEQUENCE', 
        title: 'Secuencia LD', 
        description: 'Memoria Visual • 4, 6 y 8 pasos', 
        icon: '🧠', 
        color: 'from-cyan-600 to-blue-900',
        component: lazy(() => import('./components/games/LDSequence').then(m => ({ default: m.LDSequence })))
    },
    { 
        id: 'PUZZLE', 
        title: 'Puzzle LD', 
        description: 'Rompecabezas • 3 Niveles', 
        icon: '🧩', 
        color: 'from-amber-500 to-orange-700',
        component: lazy(() => import('./components/games/LDPuzzle').then(m => ({ default: m.LDPuzzle })))
    },
    { 
        id: 'DRIBBLER', 
        title: 'Dribelador LD', 
        description: 'Arcade de Reacción • 35s', 
        icon: '⚽', 
        color: 'from-indigo-600 to-blue-800',
        component: lazy(() => import('./components/games/LDDribbler').then(m => ({ default: m.LDDribbler })))
    },
    { 
        id: 'MAHJONG', 
        title: 'Parejas LD', 
        description: 'Memoria y Rapidez', 
        icon: '🃏', 
        color: 'from-green-600 to-teal-800',
        component: lazy(() => import('./components/games/LDMahjong').then(m => ({ default: m.LDMahjong })))
    },
    { 
        id: 'TRIVIA_CAL', 
        title: 'Trivia: Cumples', 
        description: '¿Conocés a tus amigos?', 
        icon: '📅', 
        color: 'from-purple-600 to-indigo-800',
        isTrivia: true,
        triviaMode: 'CALENDAR',
        component: lazy(() => import('./components/games/LDTrivia').then(m => ({ default: m.LDTrivia })))
    },
    { 
        id: 'TRIVIA_SCOUT', 
        title: 'Trivia: Roles', 
        description: '¿Quién juega de qué?', 
        icon: '🔍', 
        color: 'from-pink-600 to-rose-800',
        isTrivia: true,
        triviaMode: 'SCOUT',
        component: lazy(() => import('./components/games/LDTrivia').then(m => ({ default: m.LDTrivia })))
    },
    { 
        id: 'TRIVIA_RADIO', 
        title: 'Trivia: Radio', 
        description: '¿Quién dijo qué en el chat?', 
        icon: '📻', 
        color: 'from-yellow-600 to-orange-800',
        isTrivia: true,
        triviaMode: 'RADIO',
        component: lazy(() => import('./components/games/LDTrivia').then(m => ({ default: m.LDTrivia })))
    }
];

export const NEW_TEAM_INITIAL_PLAYER: Player = {
    id: 1,
    firstName: 'ADMIN',
    lastName: 'INICIAL',
    nickname: 'CAPITÁN',
    pin: '0000',
    photoUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Admin&backgroundColor=4f46e5',
    role: PlayerRole.DT,
    skillLevel: 5,
    birthDate: '1990-01-01',
    isSuperAdmin: true
};

export const INITIAL_PLAYERS: Player[] = [
    { id: 1, firstName: 'Leonardo', lastName: 'Delgado', nickname: 'Leito', pin: '0000', photoUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Leito&backgroundColor=b6e3f4', role: PlayerRole.MEDIOCAMPISTA_CENTRAL, skillLevel: 5, birthDate: '1980-01-01', isSuperAdmin: true }
];

export const INITIAL_MY_TEAM: MyTeam = {
    name: 'PLAYERS LD',
    shieldUrl: '/favicon.svg',
    primaryColor: '#4f46e5',
    secondaryColor: '#60a5fa',
};

export const INITIAL_APP_SETTINGS: AppSettings = {
    superAdminPlayerId: 1, 
    isPinAuthEnabled: true,
    announcement: '¡Bienvenidos!',
};

export const translations = {
    es: {
        appTitle: "PLAYERS LD",
        home: "Convocatoria",
        fixture: "Fixture",
        tournaments: "Torneos",
        venues: "Canchas",
        rivals: "Rivales",
        myTeam: "Mi Equipo",
        logistics: "Vestuario",
        stats: "Estadísticas",
        treasury: "Tesorería",
        help: "Ayuda",
        roster: "Plantilla",
        installApp: "Instalar App",
        nextMatch: "Próximo Partido",
        callUp: "Convocatoria",
        confirm: "Confirmar",
        doubt: "En Duda",
        absent: "Ausente",
        adminMatch: "🛠️ Cargar Datos / Admin",
        share: "Compartir",
        shareStats: "Compartir Resumen",
        myProfile: "Mi Perfil",
        matchStatus: {
            PROGRAMADO: "PROGRAMADO",
            FINALIZADO: "FINALIZADO",
            SUSPENDIDO: "SUSPENDIDO"
        },
        payment: {
            paid: "Pagado",
            partial: "Parcial",
            unpaid: "Debe"
        },
        search: "Buscar...",
        loading: "Cargando...",
        back: "Volver",
        genTeams: "⚽ Armar Equipos (Aleatorio)",
        generating: "Mezclando...",
        adminOptions: "Administrar Votación",
        openVoting: "Abrir Votación",
        closeVoting: "Cerrar Votación",
        votingOpen: "HABILITADA",
        votingClosed: "DESHABILITADA",
        ratings: "⭐ Votación",
        votingStatus: "Estado de Votación",
        thirdHalf: "🍻 3er Tiempo"
    },
    en: {
        appTitle: "PLAYERS LD",
        home: "Call-up",
        fixture: "Fixture",
        tournaments: "Tournaments",
        venues: "Venues",
        rivals: "Opponents",
        myTeam: "My Team",
        logistics: "Locker Room",
        stats: "Stats",
        treasury: "Treasury",
        help: "Help",
        roster: "Roster",
        installApp: "Install App",
        nextMatch: "Next Match",
        callUp: "Call Up",
        confirm: "Confirm",
        doubt: "Maybe",
        absent: "Absent",
        adminMatch: "🛠️ Admin / Data",
        share: "Share",
        shareStats: "Share Summary",
        myProfile: "My Profile",
        matchStatus: {
            PROGRAMADO: "SCHEDULED",
            FINALIZADO: "FINISHED",
            SUSPENDIDO: "SUSPENDED"
        },
        payment: {
            paid: "Paid",
            partial: "Partial",
            unpaid: "Unpaid"
        },
        search: "Search...",
        loading: "Loading...",
        back: "Back",
        genTeams: "⚽ Generate Teams (Random)",
        generating: "Shuffling...",
        adminOptions: "Manage Voting",
        openVoting: "Open Voting",
        closeVoting: "Close Voting",
        votingOpen: "ENABLED",
        votingClosed: "DISABLED",
        ratings: "⭐ Voting",
        votingStatus: "Voting Status",
        thirdHalf: "🍻 3rd Half"
    },
    pt: {
        appTitle: "PLAYERS LD",
        home: "Convocação",
        fixture: "Calendário",
        tournaments: "Torneios",
        venues: "Campos",
        rivals: "Rivais",
        myTeam: "Meu Time",
        logistics: "Vestiário",
        stats: "Estatísticas",
        treasury: "Tesouraria",
        help: "Ajuda",
        roster: "Elenco",
        installApp: "Instalar App",
        nextMatch: "Próxima Partida",
        callUp: "Convocação",
        confirm: "Confirmar",
        doubt: "Dúvida",
        absent: "Ausente",
        adminMatch: "🛠️ Admin / Dados",
        share: "Compartilhar",
        shareStats: "Compartilhar Resumo",
        myProfile: "Meu Perfil",
        matchStatus: {
            PROGRAMADO: "AGENDADO",
            FINALIZADO: "FINALIZADO",
            SUSPENDIDO: "SUSPENSO"
        },
        payment: {
            paid: "Pago",
            partial: "Parcial",
            unpaid: "Deve"
        },
        search: "Buscar...",
        loading: "Carregando...",
        back: "Voltar",
        genTeams: "⚽ Gerar Times (Aleatório)",
        generating: "Misturando...",
        adminOptions: "Gerenciar Votacción",
        openVoting: "Abrir Votación",
        closeVoting: "Fechar Votação",
        votingOpen: "HABILITADA",
        votingClosed: "DESABILITADA",
        ratings: "⭐ Votación",
        votingStatus: "Status da Votação",
        thirdHalf: "🍻 3º Tiempo"
    }
};

export const GAME_IDEAS: GameIdea[] = [
    { id: '1', title: 'NIGHT LAB', shortDesc: 'TEST ENGINE', particleEmoji: '💀', color: '#ff0000', engineType: 'GAME' }
];

export const BACKGROUNDS: any[] = [
    { id: '1', name: 'Darkness', url: '' }
];